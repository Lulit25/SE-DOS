var express = require('express');
var app = express();
app.use(express.static('public'));
var department;
var fs = require('fs');

fs.readFile("list.json", 'utf8', function(err, data){
    department = JSON.parse(data.trim());
});
app.get('/department', function (req, res) {
    var name = req.query['name'];
    res.status(200).send(department[name]);
});
app.listen(3000);